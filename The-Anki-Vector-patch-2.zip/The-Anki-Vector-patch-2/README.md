# The-Anki-Vector Based on Python Telegram Bot ![GitHub repo size](https://img.shields.io/github/repo-size/Damantha126/The-Anki-Vector?label=Repo%20Size)
<p align="leaft">
  <img src="https://telegra.ph/file/3b6aa07aac530199d5358.png" width='600"'>
</p>
# 2 Branches available. this is main brach. swith advaced fr all fetures

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Damantha126/The-Anki-Vector.git)


### Video Tutorial:
Complete guide on deploying @TheAnkiVectorbot's clone on Heroku.

[![Tutorial](https://yt-embed.herokuapp.com/embed?v=fXXEcAkWAFU)](https://www.youtube.com/watch?v=fXXEcAkWAFU)

☆ Video by [Damantha Jasinghe](https://www.youtube.com/watch?v=fXXEcAkWAFU) ☆
[![YouTube](https://img.shields.io/badge/YouTube-Video%20Tutorial-red?logo=youtube)](https://www.youtube.com/watch?v=fXXEcAkWAFU)

## New version Avaiilable on Telegram as [The-Anki-Vector-Bot](https://t.me/TheAnkiVectorbot)
## The-Anki-Vector-Bot is the latest




The bot is based on the original work done by [PaulSonOfLars](https://github.com/PaulSonOfLars)
This repo was just revamped to suit an Anime-centric community. All original credits go to Paul and his dedication, Without his efforts, this fork would not have been possible!

All other credits mentioned on top of scripts

Should any be missing kindly let us know at [The Anki Vector bot](https://t.me/ankivectorUpdates) or simply submit a pull request on the readme.

## The Anki Vector bot the telegram Bot Project
The Advanced Branch (For PRO's)

The Anki Vector bot(advanced)

### Credits ❤
<details><summary>All Credits Here</summary>
<p>

**[Inuka Asith](https://github.com/inukaasith)** ▪ **[Prabasha](https://github.com/prabhasha-p/HexzyBot)** ▪ **[Im Janindu](https://github.com/imjanindu)** ▪ **[Devil](https://github.com/lucifeermorningstar)** ▪ **[Miss-Valentina](https://github.com/Miss-Valentina)** ▪ **[Mr-Dark-Prince](https://github.com/Mr-Dark-Prince/)** ▪ **[Anime Kaizoku](https://github.com/AnimeKaizoku)** ▪ **[thehamkercat](https://github.com/thehamkercat/)**
</details>

## Special Credits
- [Damantha](https://github.com/Damantha126) - A Co-Developer of Project
