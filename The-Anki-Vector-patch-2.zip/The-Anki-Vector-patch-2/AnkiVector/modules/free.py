__help__ = """
** You can Get Free internet file useing this bot**
❍ Use this format @EHIfilebot File name [ehi/sks/httpetc...]
❍ Join this group for more information @LIONHEARTn..
❍ Use this Video [video](https://www.youtube.com/channel/UCvYfJcTr8RY72dIapzMqFQA)
"""
__mod_name__ = "Free internet 💡 "
