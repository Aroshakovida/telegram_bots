__help__ = """
** You can get current time  useing this Bot **
❍ Use this format /time 
❍ /gettime
 
"""
__mod_name__ = "Time ⏰ "
