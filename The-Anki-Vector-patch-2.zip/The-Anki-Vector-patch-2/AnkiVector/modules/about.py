__help__ = """
** Rose Bot 🌹 - A Powerful Telegram Group Manager Bot **

All Credits & Special thanks 🌞 

🌐 First Owners [Yakari music](https://github.com/youtubeslgeekshow/call-music-plus-bot) [Damantha🇱🇰](https://t.me/Damantha_Jasinghe)[Daisy X](https://github.com/TeamDaisyX/DaisyX) 

🌐 I added
Force Subscribe for music play
song downloader 
update some customizes button and more....

🌐 Join with us for more education 📖

 [Updates Channel🔔 ](https://t.me/sl_bot_zone)
"""
__mod_name__ = "About 🇱🇰"
