__help__ = """
** You can use this module to image search etc**
❍ /img <text>: perform a image search
❍ /getqr <reply to image>: Read QR code
❍ /makeqr <reply to text>: Make QR code
"""
__mod_name__ = "Image☯️ "


