__help__ = """
** You can search any Modapp useing this Bot **
❍ Use this format @szmodappbot App name
❍ Or you can use Direct this bot in Pm @szmodappbot
"""
__mod_name__ = "Mod app 📲"
