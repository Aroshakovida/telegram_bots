__help__ = """
** You can Track any Phone no  useing this Bot **
❍  /phone <tp no> : Track Phone no
"""
__mod_name__ = "Phone📱"
