__help__ = """
** You can sea my internet speed useing this button  **
❍ Type /speedtest and send it
❍ ping /ping
❍ ding /ding
❍ pingall /pingall
"""
__mod_name__ = "speedtest💥"
