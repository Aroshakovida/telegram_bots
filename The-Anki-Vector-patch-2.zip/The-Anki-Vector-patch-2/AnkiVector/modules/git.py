__help__ = """
@szrosebot 🇱🇰
I will give information about github profile and repository ..  
 ❍ /git <username>: Get information about a GitHub user.
 ❍ /repo <name> : Get information about a GitHub  repository .
"""
__mod_name__ = "Github ☀️ "
