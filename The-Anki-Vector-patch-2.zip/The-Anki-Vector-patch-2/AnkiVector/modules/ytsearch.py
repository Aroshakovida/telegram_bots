__help__ = """
** You can search any youtube video useing this Bot **
❍ Use this format @szrosebot videoname 
"""
__mod_name__ = "YT search 🔎 "
