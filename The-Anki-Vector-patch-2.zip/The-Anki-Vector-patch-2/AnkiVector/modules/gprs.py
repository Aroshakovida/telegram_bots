__help__ = """
** You can search place  useing this Bot **
** GPS **
 ❍ /gps <Place> : Show Location on a map
"""
__mod_name__ = "gps🌎"
