__help__ = """
** You can search any Film useing this Bot **
❍ Use this format @szfilmbot film name 
❍ Or you can use Direct this bot in Pm @szfilmbot
"""
__mod_name__ = "Film 🎞"
