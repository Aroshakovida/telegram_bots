__help__ = """
  ❍ you can get any book useing this bot /book book name     
"""
__mod_name__ = "BOOk📚"
