__help__ = """
@szrosebot 🇱🇰
Blue text cleaner removed any made up commands that people send in your chat.
 ❍ /cleanblue <on/off/yes/no>: clean commands after sending
 ❍ /ignoreblue <word>: prevent auto cleaning of the command
 ❍ /unignoreblue <word>: remove prevent auto cleaning of the command
 ❍ /listblue: list currently whitelisted commands
"""
__mod_name__ = "B Text🛑"
