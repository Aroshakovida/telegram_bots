__help__ = """
** Telegraph **
- /telegraph <reply to jpg, jpeg, png, gif or mp4>: upload to telegraph.
"""
__mod_name__ = "Tgraph 👀"
