__help__ = """
 - /yt <text>: perform a youtube search
 - /ytaudio <link> or /ytvideo <link>: Downlods a video or audio from a youtube video to the bots local server
"""
__mod_name__ = "Youtube💻"
